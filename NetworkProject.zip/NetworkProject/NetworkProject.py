from scapy.all import sniff
from datetime import datetime
import logging
import threading
import signal
import matplotlib.pyplot as plt

# dictionaries and sets to store network statistics like packet details, unique address, and connection records 
packet_statistics = {"Ethernet": [], "IP": [], "TCP": [], "UDP": []}
unique_ips = set()
unique_macs = set()
latency_records = {}
throughput_counter = {"Ethernet": 0, "IP": 0, "TCP": 0, "UDP": 0}

# NEW: to track throughput history for each protocol over multiple intervals
throughput_history = {"Ethernet": [], "IP": [], "TCP": [], "UDP": []}

# Logging creation of file to record packet details
logging.basicConfig(
    filename="network_events.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

# method to log packet details of the captured packets
def log_packet(protocol, src, dest, size):
    logging.info(f"Protocol: {protocol}, Source: {src}, Destination: {dest}, Size: {size} bytes")

# handle each captured packet
def handle_packet(packet):
    now = datetime.now()  # Capture the timestamp

    # handling the ethernet layer packets
    if packet.haslayer("Ether"):
        src_mac = packet.src  # record source Ethernet
        dest_mac = packet.dst  # record destination Ethernet 
        size = len(packet)  # record Ethernet size
        unique_macs.add(src_mac)  # record source unique Ethernet address
        unique_macs.add(dest_mac)  # record destination unique Ethernet address
        throughput_counter["Ethernet"] += size  # adds the size to the throughput
        packet_statistics["Ethernet"].append(size)  # adds the details to the Network Event_Log file
        log_packet("Ethernet", src_mac, dest_mac, size)

    # handle the IP layer packets
    if packet.haslayer("IP"):
        src_ip = packet["IP"].src  # record source IP
        dest_ip = packet["IP"].dst  # record destination IP
        size = len(packet)  # record IP size 
        unique_ips.add(src_ip)  # record source unique IP address
        unique_ips.add(dest_ip)  # record destination unique IP address
        throughput_counter["IP"] += size  # adds the size to the throughput
        packet_statistics["IP"].append(size)  # adds the details to the Network Event_Log file
        log_packet("IP", src_ip, dest_ip, size)
        
        # handle TCP and UDP packets 
        if packet.haslayer("TCP") or packet.haslayer("UDP"):  # checking which protocol it is
            protocol = "TCP" if packet.haslayer("TCP") else "UDP"
            conn_key = (src_ip, dest_ip, protocol)  # record its source and destination  
            # recording timestamp for the latency calculation
            if conn_key not in latency_records:
                latency_records[conn_key] = {"start": now}
            else:
                latency_records[conn_key]["end"] = now

            throughput_counter[protocol] += size
            packet_statistics[protocol].append(size)
            log_packet(protocol, src_ip, dest_ip, size)

# method to calculate throughput periodically by seconds
def calculate_throughput(interval=10):
    while True:
        threading.Event().wait(interval)  # Wait for periodically duration 
        print("\n*** Throughput Statistics (10s) ***")
        for proto, total_bytes in throughput_counter.items():
            throughput = (total_bytes * 8) / interval  # Convert Bytes to bits and calculate throughput
            print(f"{proto}: {throughput:.2f} bps")
            throughput_history[proto].append(throughput)  # NEW: Add throughput to history
            throughput_counter[proto] = 0  # Resetting the counter after each calculation

# method to display real-time statistics every 30 seconds
def real_time_stats(interval=30):
    while True:
        threading.Event().wait(interval)  # Wait for periodically duration
        print("\n*** Real-Time Network Statistics (30s) ***")
        
        # Display Unique IP and MAC addresses
        print(f"Unique MAC Addresses: {len(unique_macs)}")
        print(f"Unique IP Addresses: {len(unique_ips)}")
        
        # Display Total packets captured by summing the length
        total_packets = sum(len(packet_statistics[proto]) for proto in packet_statistics)
        print(f"Total Packets Captured: {total_packets}")
        
        # calculate and display Average packet size for each protocol
        for proto, sizes in packet_statistics.items():
            total_size = sum(sizes)
            packet_count = len(sizes)
            avg_size = total_size / packet_count if packet_count > 0 else 0
            print(f"Average Packet Size for {proto}: {avg_size:.2f} bytes")
        
        # calculate and display TCP and UDP Connections per protocol
        tcp_connections = sum(1 for key in latency_records if key[2] == "TCP")
        udp_connections = sum(1 for key in latency_records if key[2] == "UDP")
        print(f"TCP Connections: {tcp_connections}")
        print(f"UDP Connections: {udp_connections}")
        
        # calculate and display Rate of new connections (connections per interval)
        new_connections = tcp_connections + udp_connections
        connection_rate = new_connections / interval
        print(f"Rate of New Connections: {connection_rate:.2f} connections/sec")

# method to plot results and save them based on captured data
def plot_results():
    # Read and display the contents of the log file
    print("\nReading Network Events Log before generating plots:")
    try:
        with open("network_events.log", "r") as log_file:
            for line in log_file:
                print(line.strip())  # Print each logged packet information
    except FileNotFoundError:
        print("Network Events Log not found.")

    # first plot 1. Throughput Over Time (Line)
    plt.figure()
    plt.title("Throughput Over Time")
    plt.xlabel("Time Interval (10s)")
    plt.ylabel("Throughput (bps)")
    time_intervals = range(len(throughput_history["Ethernet"]))  # NEW: Generate time intervals
    for protocol, color in zip(["Ethernet", "IP", "TCP", "UDP"], ["pink", "blue", "yellow", "red"]):
        throughput_values = throughput_history[protocol]  # NEW: Retrieve history for each protocol
        plt.plot(time_intervals, throughput_values, marker='o', linestyle='-', color=color, label=f"{protocol} Throughput")
    plt.legend()
    plt.savefig("throughput_over_time.png")  # Save the plot
    plt.close()  # Close the figure

    # second plot 2. Latency Distribution (histogram)
    plt.figure()
    latencies = [
        (timestamps["end"] - timestamps["start"]).total_seconds() * 1000
        for timestamps in latency_records.values()
        if "start" in timestamps and "end" in timestamps
    ]
    if latencies:
        plt.hist(latencies, bins=10, color="pink", edgecolor="black")
        plt.title("Latency Distribution")
        plt.xlabel("Latency (ms)")
        plt.ylabel("Frequency")
        plt.savefig("latency_distribution.png")  # Save the plot
        plt.close()  # Close the figure
    else:
        print("No latency data available to plot.")

    # third plot 3. Protocol Usage ( bar chart)
    plt.figure()
    protocol_names = ["Ethernet", "IP", "TCP", "UDP"]
    packet_counts = [len(packet_statistics[proto]) for proto in protocol_names]
    unique_counts = [len(unique_macs), len(unique_ips)]
    plt.bar(protocol_names, packet_counts, label="Packets per Protocol", alpha=0.7)
    plt.bar(["MAC", "IP"], unique_counts, label="Unique Counts", alpha=0.7, color="gray")
    plt.title("Protocol Usage")
    plt.xlabel("Protocol")
    plt.ylabel("Count")
    plt.legend()
    plt.savefig("protocol_usage.png")  # Save the plot
    plt.close()  # Close the figure

    # Show all saved plots at the end
    print("\nAll plots have been saved as PNG files.")

# method to stop sniffing and handle terminate program (graceful shutdown)
def stop_sniffing(signal, frame):
    print("\nStopping Packet Capture...")

    # Display unique IP and MAC addresses
    print(f"Total Unique IPs: {len(unique_ips)}")
    print(f"Total Unique MACs: {len(unique_macs)}")

    # display average packet size for each protocol
    print("\nFinal Average Packet Sizes:")
    for proto, sizes in packet_statistics.items():
        total_size = sum(sizes)
        packet_count = len(sizes)
        avg_size = total_size / packet_count if packet_count > 0 else 0
        print(f"{proto}: {avg_size:.2f} bytes")

    # display final total (TCP&UDP Connections) and print total connections
    tcp_connections = sum(1 for key in latency_records if key[2] == "TCP")  # TCP Connection calc
    udp_connections = sum(1 for key in latency_records if key[2] == "UDP")  # UDP connection calc
    total_connections = tcp_connections + udp_connections
    print(f"TCP Connections: {tcp_connections}")
    print(f"UDP Connections: {udp_connections}")
    print(f"Total Connections: {total_connections}")

    # call the plot results function to display graphs
    plot_results()
    exit(0)

# main execution of program
if __name__ == "__main__":
    signal.signal(signal.SIGINT, stop_sniffing)  # Ctrl+C signal handling to stop sniffing

    # Create and start threads for throughput calculation and real-time stats display
    threading.Thread(target=calculate_throughput, daemon=True).start()
    threading.Thread(target=real_time_stats, daemon=True).start()

    # Start packet sniffing with the handle_packet callback
    sniff(prn=handle_packet)